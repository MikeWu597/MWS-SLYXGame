package com.mws.slyx.listener;

import javax.tools.DocumentationTool.Location;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class PlayerRespawnListener implements Listener{
	@EventHandler
	public void PlayerRespawnEvent(Player respawnPlayer, Location respawnLocation, boolean isBedSpawn)
	{
		Bukkit.broadcastMessage(respawnPlayer.getName());
		return;
	}
}
