package com.mws.slyx;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class slyx
  extends JavaPlugin
{
  String prefix;
  ///clone -97 115 522 -60 97 493 -141 65 197 replace (((ReFix Code)))
  ///clone -81 82 68 -95 77 46 -287 67 36 replace
  public void onEnable()
  {
	  getLogger().info(ChatColor.AQUA+"扫雷英雄小游戏已完成加载！\n作者：MikeWu597");
  }
  
  public void onDisable() {}
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    if (cmd.getName().equalsIgnoreCase("s"))
    {
    	Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tp @a -278.6 68 55.5");
    	Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "clone -81 82 68 -95 77 46 -287 67 36 replace");
    	Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "clone -97 115 522 -60 97 493 -141 65 197 replace");
    	return true;
    }
    return false;
  }
  
}
