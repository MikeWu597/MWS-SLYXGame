package com.mws.slyx;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class slyx
  extends JavaPlugin implements Listener
{
  String prefix;
  int lx,ly;
  ///clone -97 115 522 -60 97 493 -141 65 197 replace (((ReFix Code)))
  ///clone -81 82 68 -95 77 46 -287 67 36 replace
  public void onEnable()
  {
	  getLogger().info(ChatColor.AQUA+"扫雷英雄小游戏已完成加载！\n作者：MikeWu597");
	  getServer().getPluginManager().registerEvents(this, this);
  }
  
  public void onDisable() {}
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    if (cmd.getName().equalsIgnoreCase("s"))
    {
    	Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tp @a -278.6 68 55.5");
    	Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "clone -81 82 68 -95 77 46 -287 67 36 replace");
    	Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "clone -97 115 522 -60 97 493 -141 65 197 replace");
    	lx=-286+(int)(Math.random()*9);//-277 ~ -286
    	ly=38+(int)(Math.random()*16);//54 ~ 38
    	//Bukkit.broadcastMessage(lx+"|"+ly);
    	/*BukkitRunnable cr = new BukkitRunnable()
    	{

			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(true)
				{
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Bukkit.broadcastMessage("hi");
				}
			}
    		
    	};
    	cr.run();
    	return true;*/
    }
    return false;
  }
  
  
  @EventHandler
  public void onPlayerJoin(PlayerJoinEvent join){
  		//监听后需要实现的代码
	  Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"tp "+join.getPlayer().getName().toString()+" -116 67 203");
	  Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"spawnpoint "+join.getPlayer().getName().toString()+" -116 67 203");
  }
  
  @EventHandler
  public void onPlayerMove(PlayerMoveEvent move){
  		//监听后需要实现的代码
	  //Bukkit.broadcastMessage(move.getTo().getBlockX()+"|"+move.getTo().getBlockZ());
	  if (move.getTo().getBlockX()==lx && move.getTo().getBlockZ()==ly)
	  {
		  Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "title @a title \"游戏结束！\"");
		  Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "kill "+move.getPlayer().getName());
	  }
  }
}
